package application;

// voir http://java.developpez.com/actu/81242/JavaFX-simuler-la-rotation-d-une-carte-sur-elle-meme-en-3D-un-billet-de-blog-de-bouye/
// pour des explications detaillees :

import javafx.animation.Interpolator;
import javafx.animation.ParallelTransition;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Point3D;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Camera;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.SceneAntialiasing;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.transform.Rotate;


public class Main extends Application {
	@Override
	public void start(Stage fenetre) {
		Carte carte = new Carte(512-(271/2),200,200,"_Trumps_-_01.jpg");
		

		// scene graphique
		fenetre.setTitle("Let's play Tarot !");
		Group cartes = new Group();
		Scene plateau = new Scene(cartes,1024,768);
		plateau.setFill(Color.BLACK);
	   
		cartes.getChildren().addAll(carte.getNodes());
		fenetre.setScene(plateau); 
		fenetre.sizeToScene(); 
		fenetre.show(); 

		// animation
		carte.flip().play();

	}

	public static void main(String[] args) {
		launch(args);
	}
}
